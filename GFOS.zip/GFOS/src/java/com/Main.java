package com;

import java.sql.*;
import sophie.SQLQuery;

public class Main {
    
//    public static void main(String[] args) throws SQLException {
//        
//        Connection myConn = null;
//        Statement myStmt = null;
//        ResultSet myRs = null;
//        
//        String user = "root";
//        String password = "gfos";
//        
//        try {
//            
//            myConn = DriverManager.getConnection("jdbc:mysql://localhost/gfos?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", user, password);
//            myStmt = myConn.createStatement();
//            myRs = myStmt.executeQuery("select * from mitarbeiter");
//            while(myRs.next()) {                
//                System.out.println(myRs.getString("Abteilung"));
//            }
//            
//        } catch(Exception e) {
//            e.printStackTrace();
//        } finally {
//            if(myRs != null) 
//                myRs.close();
//            if(myStmt != null)
//                myStmt.close();
//            if(myConn != null) 
//                myConn.close();
//           
//        }
//    }
    
    public static void main(String[] args) {
        ResultSet rs = null;
        try {
             rs = SQLQuery.query("SELECT* FROM gfos.mitarbeiter;", "root", "gfos");
             rs.next();
             System.out.println(rs .getString("Personalnummer"));
        } catch(SQLException e) {
            e.printStackTrace();
        }
        
    }
    
}
