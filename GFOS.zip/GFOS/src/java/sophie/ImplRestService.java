/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sophie;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.codehaus.jackson.map.ObjectMapper;

/**
 *
 * @author LoL
 */
@Path("/restService")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ImplRestService implements RestService{

    @Override
    public String addMitarbeiter(Mitarbeiter m) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    @GET
    @Path("/get/{pn}")
    public String getMitarbeiter(@PathParam("pn")String pn) throws SQLException{
        if(pn == null || pn.length() != 12)
            return null;
        ResultSet rs;
        try {
            rs = SQLQuery.query("SELECT* FROM gfos.mitarbeiter WHERE gfos.mitarbeiter.personalnummer = " + pn + ";", "root", "gfos");
        } catch(SQLException e) {
            e.printStackTrace();
            return null;
        }
        Mitarbeiter m = createMitarbeiterFromQuery(rs);
        String json = createJsonFromMitarbeiter(m);
        return json;
    }

    @Override
    public String getAllMitarbeiter() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private Mitarbeiter createMitarbeiterFromQuery(ResultSet rs) throws SQLException{
        Mitarbeiter m = new Mitarbeiter();
        m.setPersonalnummer(rs.getString("Personalnummer"));
        m.setName(rs.getString("Name"));
        m.setVorname(rs.getString("Vorname"));
        
        return m;
    }
    
    private String createJsonFromMitarbeiter(Mitarbeiter m) {
        ObjectMapper om = new ObjectMapper();
        String s;
        try {
            s = om.writeValueAsString(m);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return s;
    }
    
}
