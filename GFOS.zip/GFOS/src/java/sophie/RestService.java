package sophie;

import java.sql.SQLException;

public interface RestService {
    
    public String addMitarbeiter(Mitarbeiter m);
    
    public String getMitarbeiter(String pn) throws SQLException;
    
    public String getAllMitarbeiter();
}
