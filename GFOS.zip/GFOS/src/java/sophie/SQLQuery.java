package sophie;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLQuery {
    
    public static ResultSet query(String stmt, String user, String password) throws SQLException{
        
        Connection myConn = null;
        Statement myStmt = null;
        ResultSet myRs = null;
        
        try {
            
            myConn = DriverManager.getConnection("jdbc:mysql://localhost/gfos?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", user, password);
            myStmt = myConn.createStatement();
            myRs = myStmt.executeQuery(stmt);         
            
        } catch(Exception e) {
            e.printStackTrace();
        } 
        
        return myRs;
    }
    
}
